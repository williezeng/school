# Assignment 1: Images as Functions (arrays or matrices of numbers)

## Description
The purpose of this problem set is to make sure you can set up your development environment, load an image, manipulate the values, produce some output, and submit the code along with the report.

## Instructions

See this assignment's google doc and piazza post.
