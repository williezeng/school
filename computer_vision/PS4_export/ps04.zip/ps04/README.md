## Problem Set 4: Motion Detection

### Description

Problem Set 4 introduces optic flow as the problem of computing a dense flow field where a flow field is a vector field <u(x,y), v(x,y)>

## Instructions

See this assignment's google doc and piazza post.
